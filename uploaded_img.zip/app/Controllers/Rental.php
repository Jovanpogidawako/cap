<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\RentingModel;
use DateTime;

class Rental extends BaseController
{
    public function index()
    {
        $model = new RentingModel();
        
        // Check if the user is logged in
        if (!session()->get('user_id')) {
            return redirect()->to('/signin')->with('message', 'Please log in to access this page.');
        }
        
        // Get all rentals
        $rentals = $model->findAll();
        
        // Prepare data for the view
        $data = [
            'rentals' => $rentals,
            'user_id' => session()->get('user_id'),
            'user_name' => session()->get('user_name'),
            'user_phone' => session()->get('user_phone'),
            'user_email' => session()->get('user_email')
        ];
        
        return view('user/renting', $data);
    }
    
    public function submit()
    {
        log_message('debug', 'Rental submission started');
    
        // Check if user is logged in
        if (!session()->get('user_id')) {
            log_message('error', 'Rental submission attempted without user_id in session');
            return $this->response->setJSON([
                'success' => false,
                'message' => 'User not logged in'
            ]);
        }
    
        log_message('debug', 'User ID from session: ' . session()->get('user_id'));
    
        $model = new RentingModel();
    
        // Validate required fields
        $rules = [
            'firstlocation' => 'required',
            'secondlocation' => 'required',
            'name' => 'required',
            'phone' => 'required',
            'start_date' => 'required',
            'end_date' => 'required',
            'start_time' => 'required',
            'end_time' => 'required',
            'price' => 'required|numeric',
        ];
    
        if (!$this->validate($rules)) {
            log_message('error', 'Validation failed: ' . json_encode($this->validator->getErrors()));
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $this->validator->getErrors()
            ]);
        }
    
        // Get form data
        $data = [
            'user_id' => session()->get('user_id'),
            'FirstLocation' => $this->request->getVar('firstlocation'),
            'SecondLocation' => $this->request->getVar('secondlocation'),
            'Name' => $this->request->getVar('name'),
            'Phone' => $this->request->getVar('phone'),
            'StartDate' => $this->request->getVar('start_date'),
            'EndDate' => $this->request->getVar('end_date'),
            'StartTime' => $this->request->getVar('start_time'),
            'EndTime' => $this->request->getVar('end_time'),
            'price' => $this->request->getVar('price'),
            'Status' => 'pending',
            'created_at' => date('Y-m-d H:i:s')
        ];
    
        log_message('debug', 'Rental data: ' . json_encode($data));
    
        try {
            // Insert data into the database
            $insertId = $model->insert($data);
    
            if ($insertId === false) {
                log_message('error', 'Rental insertion failed. Data: ' . json_encode($data));
                throw new \Exception('Failed to insert rental record');
            }
    
            log_message('info', 'Rental submitted successfully. ID: ' . $insertId . ', User ID: ' . $data['user_id']);
    
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Rental submitted successfully'
            ]);
        } catch (\Exception $e) {
            log_message('error', 'Rental submission error: ' . $e->getMessage());
            
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error occurred while submitting the rental: ' . $e->getMessage()
            ]);
        }
    }

    public function adminIndex()
    {
        $model = new RentingModel();
        $rentals = $model->findAll();

        // Update status and color for each rental
        foreach ($rentals as &$rental) {
            $rental['Status'] = $this->calculateRentalStatus($rental);
            $rental['statusColor'] = $this->getStatusColor($rental['Status']);
        }

        return view('admin/rental_management', ['rentals' => $rentals]);
    }

    public function getRentals()
    {
        $model = new RentingModel();
        $rentals = $model->findAll(); // Retrieve all rentals

        $events = [];
        foreach ($rentals as $rental) {
            // Determine rental status based on current date and time
            $currentDateTime = new DateTime();
            $startDateTime = new DateTime($rental['StartDate'] . ' ' . $rental['StartTime']);
            $endDateTime = new DateTime($rental['EndDate'] . ' ' . $rental['EndTime']);
            $status = 'pending';

            if ($currentDateTime >= $startDateTime && $currentDateTime <= $endDateTime) {
                $status = 'ongoing';
            } elseif ($currentDateTime > $endDateTime) {
                $status = 'done';
            }

            $rental['Status'] = $status;

            $events[] = [
                'id' => $rental['RentalID'],
                'title' => $rental['Name'],
                'start' => $rental['StartDate'] . 'T' . $rental['StartTime'],
                'end' => $rental['EndDate'] . 'T' . $rental['EndTime'],
                'color' => $this->getRentalColor($status),
                'extendedProps' => [
                    'firstLocation' => $rental['FirstLocation'],
                    'secondLocation' => $rental['SecondLocation'],
                    'phone' => $rental['Phone'],
                    'price' => $rental['price'],
                    'status' => $status
                ]
            ];
        }

        return $this->response->setJSON($events);
    }

    public function updateRental()
    {
        $model = new RentingModel();

        // Get rental ID and form data
        $rentalId = $this->request->getVar('rental_id');
        $data = [
            'FirstLocation' => $this->request->getVar('firstlocation'),
            'SecondLocation' => $this->request->getVar('secondlocation'),
            'Name' => $this->request->getVar('name'),
            'Phone' => $this->request->getVar('phone'),
            'StartDate' => $this->request->getVar('start_date'),
            'EndDate' => $this->request->getVar('end_date'),
            'StartTime' => $this->request->getVar('start_time'),
            'EndTime' => $this->request->getVar('end_time'),
        ];

        // Update the rental record in the database
        $model->update($rentalId, $data);

        // Redirect back to the rental management page after updating
        return redirect()->to(site_url('rentman'))->with('status', 'Rental updated successfully');
    }

    public function deleteRental($id)
    {
        $model = new RentingModel();
        $model->delete($id); // Delete the rental by its ID

        // Redirect to admin page with success message
        return redirect()->to(site_url('rentman'))->with('status', 'Rental deleted successfully');
    }

    public function history()
    {
        $model = new RentingModel();
        $rentals = $model->findAll(); // Retrieve all rentals

        // Update status and color for each rental
        foreach ($rentals as &$rental) {
            $rental['Status'] = $this->calculateRentalStatus($rental);
            $rental['statusColor'] = $this->getStatusColor($rental['Status']);
        }

        return view('user/renting_history', ['rentals' => $rentals]);
    }

    private function calculateRentalStatus($rental)
    {
        $currentDateTime = new DateTime();
        $startDateTime = new DateTime($rental['StartDate'] . ' ' . $rental['StartTime']);
        $endDateTime = new DateTime($rental['EndDate'] . ' ' . $rental['EndTime']);

        if ($currentDateTime < $startDateTime) {
            return 'Upcoming';
        } elseif ($currentDateTime >= $startDateTime && $currentDateTime <= $endDateTime) {
            return 'Ongoing';
        } else {
            return 'Completed';
        }
    }

    private function getStatusColor($status)
    {
        switch ($status) {
            case 'Completed':
                return '#28a745'; // Green
            case 'Ongoing':
                return '#007bff'; // Blue
            case 'Upcoming':
                return '#ffc107'; // Yellow
            default:
                return '#6c757d'; // Grey
        }
    }
    
    public function show()
    {
        $model = new RentingModel();
        $rentals = $model->findAll(); // Retrieve all rentals
        foreach ($rentals as &$rental) {
            $rental['Status'] = $this->calculateRentalStatus($rental);
            $rental['statusColor'] = $this->getStatusColor($rental['Status']);
        }

        return view('user/renting_history', ['rentals' => $rentals]);
    }
    public function mapping() 
    {
        $model = new RentingModel();
        
        // Fetch all rental records
        $data['rental_data'] = $model->findAll(); 

        // Check if rental data was retrieved
        if (empty($data['rental_data'])) {
            session()->setFlashdata('message', 'No rental information found.');
        }

        return view('admin/rental_map', $data); // Pass data to the view
    }
  }