<!-- 
  - #HERO
-->
<style>
    h2 {
        font-size: 2rem; /* Adjust size as needed */
        color: #1a1a1a; /* Dark color for better readability */
        margin-bottom: 20px; /* Spacing below the heading */
        font-weight: 700; /* Bold text */
        text-align: left; /* Center alignment */
        text-transform: uppercase; /* Uppercase text */
        letter-spacing: 1px; /* Spacing between letters */
    }
</style>


<article>
    <!-- #HERO -->
    <section class="section hero" id="home">
        <div class="container">
            
        <!-- Greeting message -->
<div class="hero-content">
    <h2>
        <?php if (isset($user['name'])): ?>
            Welcome, <?= esc($user['name']) ?>
        <?php else: ?>
            Welcome to Our Service
        <?php endif; ?>
    </h2>
    <p class="hero-text">The easy way to takeover a lease</p>
</div>
            
            <div class="hero-content">
                <h2 class="h1 hero-title">BROO BROOM!!</h2>
            </div>
            
            <div class="hero-banner"></div>
                
            <form action="" class="hero-form">
                <div class="input-wrapper">
                    <label for="input-1" class="input-label">Car, model, or brand</label>
                    <input type="text" name="car-model" id="input-1" class="input-field" placeholder="What car are you looking for?">
                </div>
                <div class="input-wrapper">
                    <label for="input-2" class="input-label">Max. monthly payment</label>
                    <input type="text" name="monthly-pay" id="input-2" class="input-field" placeholder="Add an amount in $">
                </div>
                <div class="input-wrapper">
                    <label for="input-3" class="input-label">Make Year</label>
                    <input type="text" name="year" id="input-3" class="input-field" placeholder="Add a minimal make year">
                </div>
                <a href="/cars" class="btn" aria-labelledby="aria-label-txt">
                    <span id="aria-label-txt">Explore cars</span>
                </a>
            </form>
        </div>
    </section>
</article>

