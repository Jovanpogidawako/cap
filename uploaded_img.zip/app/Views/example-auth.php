<?= $this->extend('backend/layout/auth-layout') ?>
<?=$this->section('content') ?>

auth page

<?=$this->endSection() ?>