<?= $this->include('layout/header') ?>

<?= $this->include('layout/hero') ?>

<?= $this->include('layout/getstarted') ?>

<?= $this->include('layout/footer') ?>
