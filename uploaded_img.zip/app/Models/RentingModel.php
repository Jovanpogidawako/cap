<?php
namespace App\Models;

use CodeIgniter\Model;

class RentingModel extends Model
{
    protected $table            = 'renting';
    protected $primaryKey       = 'RentalID';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'user_id',
        'product_id', // Add product_id to connect with products
        'FirstLocation',
        'SecondLocation',
        'Name',
        'Phone',
        'StartDate',
        'EndDate',
        'StartTime',
        'EndTime',
        'price',
        'Status',
        'created_at',
    ];

    // ... (other properties remain unchanged)

    // Method to get rentals with user and product info
    public function getRentalsWithUserAndProductInfo()
    {
        return $this->select('
                user_form.id AS user_id, 
                user_form.name AS user_name, 
                user_form.email AS user_email, 
                user_form.phone AS user_phone, 
                user_form.address AS user_address, 
                renting.RentalID AS rental_id, 
                renting.FirstLocation, 
                renting.SecondLocation, 
                renting.StartDate, 
                renting.EndDate, 
                renting.StartTime, 
                renting.EndTime, 
                renting.price, 
                renting.Status, 
                products.model AS product_model, 
                products.price AS product_price
            ')
            ->join('user_form', 'user_form.id = renting.user_id')
            ->join('products', 'products.id = renting.product_id') // Join with products table
            ->findAll();
    }
    public function getRentalsForUser($userId)
    {
        $rentals = $this->where('user_id', $userId)->findAll();
        log_message('debug', "Rentals for user $userId: " . json_encode($rentals));
        return $rentals;
    }

public function findAllForUser($userId)
    {
        $rentals = $this->where('user_id', $userId)->findAll();
        log_message('debug', "Rentals for user $userId: " . json_encode($rentals));
        return $rentals;
    }
    // ... (other methods remain unchanged)
}
